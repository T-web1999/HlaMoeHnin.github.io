# Hla Moe Hnin — Personal Portfolio Website

This is a responsive, one-page portfolio website for GitHub Pages. It uses plain HTML and CSS, so you do not need to install software or know how to code.

## Files in this folder

- `index.html` — website content
- `styles.css` — navy-and-white design and responsive layout
- `assets/` — add your CV and optional profile photo here

## Publish it free with GitHub Pages

### Step 1 — Sign in to GitHub
Go to https://github.com/ and sign in to your account. If you do not have an account, create one for free.

### Step 2 — Create the website repository
1. Click the `+` icon at the top right, then choose **New repository**.
2. For the repository name, enter **HlaMoeHnin.github.io** (use this exact spelling if your GitHub username is `HlaMoeHnin`).
3. Choose **Public**.
4. Tick **Add a README file** if that option appears.
5. Click **Create repository**.

If your GitHub username is not exactly `HlaMoeHnin`, replace that part of the repository name with your actual username, for example `YOURUSERNAME.github.io`.

### Step 3 — Upload the website files
1. Open your new repository.
2. Click **Add file** → **Upload files**.
3. On your computer, unzip the downloaded portfolio ZIP file.
4. Upload `index.html`, `styles.css`, and the `assets` folder contents. Keep `index.html` and `styles.css` at the top level of the repository; do not upload only the ZIP file.
5. If GitHub does not let you upload an empty folder, that is normal. You can upload `assets/README.txt` first, or upload your CV into `assets` later.
6. Add a commit message such as `Add portfolio website`, then click **Commit changes**.

### Step 4 — Turn on GitHub Pages
1. In the repository, open **Settings**.
2. Select **Pages** from the left menu.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Choose branch **main** and folder **/(root)**.
5. Click **Save**.
6. Wait a few minutes, then visit `https://HlaMoeHnin.github.io/`. If the page does not appear immediately, wait a little longer and refresh.

Official help: https://docs.github.com/en/pages/quickstart

## Before sharing with employers

### Add your CV
1. Save your final CV as a PDF named exactly `Hla-Moe-Hnin-CV.pdf`.
2. In the repository, open the `assets` folder and upload that PDF.
3. The CV button on the website links to `assets/Hla-Moe-Hnin-CV.pdf`.

The button will not work until you upload that file. Check the PDF contains only information you are comfortable sharing with recruiters.

### Add your email and LinkedIn
1. Open `index.html` in your GitHub repository.
2. Click the pencil/edit icon.
3. Find `YOUR-EMAIL@example.com` and replace it with your professional email address.
4. Find `Add your LinkedIn profile URL` and replace `https://www.linkedin.com/` with your actual LinkedIn profile URL.
5. Click **Commit changes**.

### Add your photo (optional)
The current page uses a designed photo placeholder. To use your own image:
1. Upload a headshot to `assets` and name it `profile.jpg`.
2. In `index.html`, find the `<div class="photo-placeholder"...>` section in the hero area.
3. Replace that whole `div` with:
   `<img class="profile-photo" src="assets/profile.jpg" alt="Portrait of Hla Moe Hnin">`
4. Open `styles.css` and add this rule anywhere:
   `.profile-photo { width: 100%; aspect-ratio: 4 / 5; object-fit: cover; border-radius: 14px; border: 1px solid #667b90; }`
5. Commit the changes. You can keep the placeholder if you prefer not to show a photo.

## Personalise your portfolio
- Read every section carefully and update any wording that does not precisely match your experience.
- Add only verified results and achievements. Do not publish confidential client or vendor information.
- Project cards are outlines for you to complete; they are not claims that separate published projects already exist.
- If you want to change text, edit `index.html`. To change colours or spacing, edit `styles.css`.
- Every time you commit changes, GitHub Pages will rebuild the site automatically.

## Privacy and accuracy
The website is public. Do not upload passport details, home address, date of birth, immigration documents, private references, or any other information you would not want anyone to see. Check that all job dates, titles and qualifications are correct before sharing.
